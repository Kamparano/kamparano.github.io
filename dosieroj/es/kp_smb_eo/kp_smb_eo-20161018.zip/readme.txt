Super Mario Bros. (JU) Esperanto-Traduko
Tradukita de Kamparano

20161018

Originala ROM:
- Super Mario Bros. (Japana/Usona)
- CRC32: 3337ec46
- MD5: 811b027eaf99c2def7b933c5208636de
- SHA-1: ea343f4e445a9050d4b4fbac2c77d0693b1d0922
- SHA-256: f61548fdf1670cffefcc4f0b7bdcdd9eaba0c226e3b74f8666071496988248de 

Permesata al vi per Creative Commons Attribution-ShareAlike 4.0.
Vidu license.txt por pli da informo.

Por aldoni:
$ xxd <ORIGINALA ROM> | sed -f fliko.sed - | xxd -r > <NOVA ROM>
